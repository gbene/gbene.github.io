import numpy as np
import pyvista as pv



def create2dsections(segment_data,stat_loc,depth,ignore_geo=False,use_texture=True):

    data = np.array(segment_data)


    # print(raw_data.shape)
    seg_traces,seg_samples = data.shape
    # print(seg_traces,seg_samples)


    if ignore_geo:
        stat_loc = np.mgrid[0:1,0:seg_traces,0:1].reshape(3,-1).T

    offset = np.array([stat_loc[0,0],stat_loc[0,1]]).round(-2)

    stat_loc[:,0] -= offset[0]
    stat_loc[:,1] -= offset[1]

    z = np.linspace(0,depth,seg_samples)
    z = np.tile(z,seg_traces)
    # print(z)
    tr = np.repeat(stat_loc,seg_samples,axis=0)

    tr[:,2] -= z
    # print(tr.shape)
    # start = 0
    # end = seg_samples
    # for i in range(seg_traces):
    #     tr[start:end,2] -= z
    #     start += seg_samples
    #     end +=seg_samples

    mesh = pv.StructuredGrid()
    mesh.points = tr
    mesh.dimensions = (1,seg_samples,seg_traces)
    if use_texture:
        mesh['values'] = data.flatten()

    # sections.append([mesh,clim,values])
    return mesh,tr
        # plotter.add_mesh(poly,cmap='seismic',clim=[-vm0-0.01*std0,vm0+0.01*std0],style='surface')
