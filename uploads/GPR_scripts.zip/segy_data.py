import ftplib
# import matplotlib.pyplot as plt

from create_mesh import create2dsections
# from vol_plotter import v_plotter
import numpy as np
import pyvista as pv
from vtk import vtkAppendPolyData
from scipy import signal
from obspy.signal.trigger import classic_sta_lta
import matplotlib.pyplot as plt


def trace_viewer(list_segments):
    appender = vtkAppendPolyData()
    plotter = pv.Plotter(notebook=False)
    # print(len(list_segments))
    for i,segment in enumerate(list_segments):
        seg = pv.Spline(segment,20)
        seg.cell_data['segment number'] = i+1
        plotter.add_mesh(seg)
    plotter.add_camera_orientation_widget()
    return plotter

def point_cloud(list_segments,list_data_stream,list_depth,out_file=None,view=None):
    appender = vtkAppendPolyData()
    pc = pv.PolyData()
    if view:
        plotter = pv.Plotter(notebook=False)
        plotter.add_camera_orientation_widget()
        plotter.show_grid()
    else:
        plotter = None
    tot_seg = len(list_segments)

    for i,segment in enumerate(list_segments):
        print(f'processing {i+1}/{tot_seg} segment')
        # seg = pv.Spline(segment,1)
        # seg.cell_data['segment number'] = i+1
        # seg.plot()
        mesh,xyz = create2dsections(list_data_stream[i],segment,list_depth[i])

        if view == 'mesh':
            plotter.add_mesh(mesh)

        seg_poly = pv.PolyData(xyz)


        seg_poly['intensity'] = list_data_stream[i].flatten()

        appender.AddInputData(seg_poly)
        # plotter.add_mesh(seg)
    appender.Update()
    pc.ShallowCopy(appender.GetOutput())

    if out_file:
        print('Saving PC')
        pc.save(f'{out_file}_pc.vtk')
        print('PC saved')

    if view == 'pc':
        plotter.add_mesh(pc)


    return pc,plotter


def create_volume(pc,res,out_file=None):

    plotter = pv.Plotter()
    x_min = np.array(pc.outline().points[:,0].min())
    x_max = np.array(pc.outline().points[:,0].max())
    y_min = np.array(pc.outline().points[:,1].min())
    y_max = np.array(pc.outline().points[:,1].max())
    z_min = np.array(pc.outline().points[:,2].min())
    z_max = np.array(pc.outline().points[:,2].max())

    x_range = x_max-x_min
    y_range = y_max-y_min
    z_range = z_max-z_min

    x_res = res
    y_res = res
    z_res = res

    # origin = pv.Sphere(center=(x_min,y_min,z_min),radius=0.5)
    grid = pv.UniformGrid()

    grid.dimensions = np.array([x_res,y_res,z_res])+1

    grid.spacing = (x_range/x_res,y_range/y_res,z_range/z_res)
    grid.origin = (x_min,y_min,z_min)
    # plotter = pv.Plotter()
    # pc['intensity'] = np.abs(pc['intensity'])
    # plotter.add_mesh(grid.outline())
    # plotter.add_mesh(pc)
    # plotter.show()

    vol = grid.interpolate(pc,progress_bar=True)
    if out_file:
        vol.save(f'{out_file}_vol_{x_res}.vtk')
    return vol,[x_range,y_range,z_range]



def pc_layers(pc,depth,layer_width):
    print('Adding Z prop')
    pc['Z'] = pc.points[:,2]
    # print(pc)

    n_layers = depth/layer_width
    layer_zs = np.linspace(0,-depth,int(n_layers))

    pc_layers = pv.PolyData()
    appender = vtkAppendPolyData()

    plotter = pv.Plotter()
    start = 0
    for end in range(1,len(layer_zs)):
        # print(end)
        # print('Thresholding')
        print([layer_zs[end],layer_zs[start]])
        pc_thresh = pc.threshold([layer_zs[end],layer_zs[start]],scalars='Z')
        # mean = np.mean()
        print(pc_thresh['intensity'])
        # print(pc_thresh)
        # plotter.add_mesh(pc_thresh.outline())
        start = end
    plotter.show()




# data = vol.point_data['intensity']
#
# v0 = np.percentile(data,90)
# std0 = np.std(data)
#
# clim=[-v0-0.01*std0,v0+0.01*std0]
# plotter.add_volume(vol)
# # plotter.add_mesh(pc)
# # plotter.add_mesh(origin,color='r')
# # plotter.add_mesh(grid,style='wireframe')
# # plotter.add_camera_orientation_widget()
# plotter.show()

# interact(local=locals())



# plotter.add_mesh(pc)
# plotter.show()






# pc = pv.PolyData(header_data)
# print(list_header_data[0])
#
# header_data.loc[header_data['mark']==255,'mark'] = 0 #set strange 255 marker as 0
#
# header_data.loc[3400,'mark'] = 2 # add missing marker
#
# # print(header_data.loc[header_data['mark']>0,'mark'])
#
#
#
# segments,stat_loc = segment_divider(data_stream,header_data) # Divide and reorient the data
