from obspy import read as ob_read
import struct
import pandas as pd
import numpy as np
import sys

def SEGY_PRISM_header(GPRfile,use_alt=False,use_scal=True,conv_term=0.09):

    header_df = pd.DataFrame()
    data_stream = ob_read(GPRfile)

    n_traces = len(data_stream)


    gpr_id = []
    gpr_lon = []
    gpr_lat = []
    gpr_alt = []
    gpr_mark = []
    gpr_scal = []



    with open(GPRfile,"rb") as f:
        data = f.read()

    byte_type = sum(struct.unpack('h', data[3224:3226]))
    # print(byte_type)
    dt = sum(struct.unpack('h', data[3216:3218]))
    n_samples = sum(struct.unpack('h', data[3220:3222]))

    for il in range(n_traces):
        h_start=3600+il*(240+n_samples*2)
        # lon1 = sum(struct.unpack('f', data[h_start+72:h_start+76]))
        # lat1 = sum(struct.unpack('f', data[h_start+76:h_start+80]))
        # lon1 = sum(struct.unpack('f', data[h_start+80:h_start+84]))
        # lat1 = sum(struct.unpack('f', data[h_start+84:h_start+88]))
        id =  sum(struct.unpack('i', data[h_start:h_start+4]))
        lon1 = sum(struct.unpack('d', data[h_start+182:h_start+190]))
        lat1 = sum(struct.unpack('d', data[h_start+190:h_start+198]))
        if use_alt:
            alt1 = sum(struct.unpack('f', data[h_start+40:h_start+44]))
        else:
            alt1 = 0
        mark = sum(struct.unpack('h', data[h_start+238:h_start+240]))
        scalar = sum(struct.unpack('h', data[h_start+70:h_start+72]))

        if use_scal:
            if scalar < 0 and scalar !=0:
                lon1 *=np.abs(scalar)
                lat1 *=np.abs(scalar)
            if scalar > 0 and scalar !=0:
                lon1 /=np.abs(scalar)
                lat1 /=np.abs(scalar)
            # header_df['scalar'] = gpr_scal
            gpr_scal.append(scalar)



        gpr_id.append(id)
        gpr_lon.append(lon1)
        gpr_lat.append(lat1)
        gpr_alt.append(alt1)
        gpr_mark.append(mark)


    header_df['id'] = gpr_id
    header_df['lon'] = gpr_lon
    header_df['lat'] = gpr_lat
    header_df['alt'] = gpr_alt
    header_df['mark'] = gpr_mark


    time_range = (dt/1000)*n_samples
    depth = (time_range*conv_term)/2

    return n_traces,n_samples,time_range,depth,scalar,header_df,data_stream


def segy_writer(segments,header_df,GPRfile):
    # n=
    for s,segment in enumerate(segments):
        n_traces = len(segment)
        with open(GPRfile,"rb") as f:
            data = f.read()

        n_samples = sum(struct.unpack('h', data[3220:3222]))
        with open(f'test{s}.sgy','wb') as f:
            f.write(data[:3600])
            for il in range(n_traces):
                h_start=3600+il*(240+n_samples*2)
                h_end = h_start+240
                f.write(data[h_start:h_end])




        # segment.stats = AttribDict()
        # segment.stats.textual_file_header = 'Textual Header!'
        # segment.stats.binary_file_header = SEGYBinaryFileHeader()
        # segment.stats.binary_file_header.data_sample_format_code = 5
        # for i,tr in enumerate(segment):
        #     tr.data = np.require(tr.data, dtype=np.float32)
        #     tr.stats.segy.trace_header = SEGYTraceHeader()
        #     tr.stats.segy.trace_header.trace_sequence_number_within_line = header_df.loc[i,'id']
        #     tr.stats.segy.trace_header.surface_elevation_at_source = header_df.loc[i,'alt']
        #     tr.stats.segy.trace_header.scalar_to_be_applied_to_all_elevations_and_depths = -header_df.loc[i,'scalar']
        #     tr.stats.segy.trace_header.scalar_to_be_applied_to_all_coordinates = -header_df.loc[i,'scalar']
        #     tr.stats.segy.trace_header.source_coordinate_x = header_df.loc[i,'lon']
        #     tr.stats.segy.trace_header.source_coordinate_y = header_df.loc[i,'lat']
        #     tr.stats.segy.trace_header.number_of_samples_in_this_trace = len(tr)
        #     segment[i] = tr
        # segment.write(f'test{s}.sgy',format="SEGY")

def segment_divider(data,header_data,reverse=False,use_alt=False):
    markers = header_data.loc[header_data['mark']>0,:].reset_index()
    segments = []
    stat_loc = []

    dir = 1
    for i,m in enumerate(markers['mark']):

        if m%2 != 0:
            # print(data[m])
            start = markers.loc[i,'index']
            end = markers.loc[i+1,'index']

            # print(start,end)
            if reverse:
                if dir == 1:
                    segments.append(data[start:end+1])
                elif dir == -1:
                    segments.append(data[start:end+1].reverse())
                dir *= -1
            else:
                segments.append(data[start:end+1])

            if not use_alt:
                header_data.loc[start:end,'alt'] = 0

            stat_loc.append(header_data.loc[start:end
            ,['lon','lat','alt']].values)


    return segments,stat_loc
